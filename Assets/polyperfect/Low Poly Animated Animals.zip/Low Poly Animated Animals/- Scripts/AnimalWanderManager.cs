﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Polyperfect.Common;

namespace Polyperfect.Animals
{
    public class AnimalWanderManager : Common_WanderManager { }
}



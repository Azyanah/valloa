﻿using Polyperfect.Common;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Polyperfect.Animals
{
    public class Animal_AIStats : AIStats { }
}
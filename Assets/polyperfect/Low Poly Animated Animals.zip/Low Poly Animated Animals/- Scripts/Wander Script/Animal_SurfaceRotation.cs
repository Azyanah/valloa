﻿using Polyperfect.Common;
using UnityEngine;

namespace Polyperfect.Animals
{
    public class Animal_SurfaceRotation : Common_SurfaceRotation { }
}